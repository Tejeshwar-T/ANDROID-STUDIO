package com.example.exp4;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText e1, e2;
    Button b1, b2, b3, b4, b5, b6;
    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);

        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);

        db = openOrCreateDatabase("Student", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS nametb(name TEXT, place TEXT)");

        refreshCursor();

        // INSERT
        b1.setOnClickListener(v -> {
            if (e1.getText().toString().isEmpty() ||
                    e2.getText().toString().isEmpty()) {
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            db.execSQL("INSERT INTO nametb VALUES('" +
                    e1.getText().toString() + "','" +
                    e2.getText().toString() + "')");

            Toast.makeText(this, "Insert Success", Toast.LENGTH_SHORT).show();
            e1.setText("");
            e2.setText("");
            refreshCursor();
        });

        // FIRST RECORD
        b2.setOnClickListener(v -> {
            if (c != null && c.getCount() > 0 && c.moveToFirst()) {
                openNextActivity(c.getString(0), c.getString(1));
            } else {
                Toast.makeText(this, "No Records Found", Toast.LENGTH_SHORT).show();
            }
        });

        // NEXT RECORD
        b3.setOnClickListener(v -> {
            if (c != null && c.moveToNext()) {
                openNextActivity(c.getString(0), c.getString(1));
            } else {
                Toast.makeText(this, "No More Records", Toast.LENGTH_SHORT).show();
            }
        });

        // VIEW ALL
        b4.setOnClickListener(v -> {
            Cursor data = db.rawQuery("SELECT * FROM nametb", null);

            if (data.getCount() == 0) {
                showDialog("Error", "No Data Found");
                data.close();
                return;
            }

            StringBuilder sb = new StringBuilder();
            while (data.moveToNext()) {
                sb.append("Name : ").append(data.getString(0)).append("\n");
                sb.append("Place : ").append(data.getString(1)).append("\n\n");
            }

            showDialog("Student Details", sb.toString());
            data.close();
        });

        // DELETE
        b5.setOnClickListener(v -> {
            db.execSQL("DELETE FROM nametb WHERE name='" +
                    e1.getText().toString() + "'");

            Toast.makeText(this, "Delete Success", Toast.LENGTH_SHORT).show();
            refreshCursor();
        });

        // UPDATE
        b6.setOnClickListener(v -> {
            db.execSQL("UPDATE nametb SET place='" +
                    e2.getText().toString() +
                    "' WHERE name='" +
                    e1.getText().toString() + "'");

            Toast.makeText(this, "Update Success", Toast.LENGTH_SHORT).show();
            refreshCursor();
        });
    }

    private void refreshCursor() {
        if (c != null) {
            c.close();
        }
        c = db.rawQuery("SELECT * FROM nametb", null);
    }

    private void openNextActivity(String name, String place) {
        Intent i = new Intent(this, MainActivity2.class);
        i.putExtra("na", name);
        i.putExtra("pl", place);
        startActivity(i);
    }

    private void showDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
