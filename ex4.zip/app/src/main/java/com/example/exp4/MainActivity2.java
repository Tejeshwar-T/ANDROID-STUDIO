package com.example.exp4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    TextView t1, t2;
    Button b7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        b7 = findViewById(R.id.b7);

        // Get data from MainActivity
        Intent intent = getIntent();
        if (intent != null && intent.getExtras() != null) {
            String name = intent.getStringExtra("na");
            String place = intent.getStringExtra("pl");

            t1.setText("Name : " + (name != null ? name : ""));
            t2.setText("Place : " + (place != null ? place : ""));
        }

        // Button click to go back to MainActivity
        b7.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity2.this, MainActivity.class);
            startActivity(i);
            finish();   // closes current activity
        });
    }
}

