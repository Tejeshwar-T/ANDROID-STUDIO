package com.example.ex7;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText lat,lang;
        Button b;
        lat=(EditText) findViewById(R.id.e1);
        lang=(EditText) findViewById(R.id.e2);
        b=(Button) findViewById(R.id.b1);
        Bundle c=new Bundle();
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.putString("lat",lat.getText().toString());
                c.putString("lang",lang.getText().toString());
                Intent i=new Intent(getApplicationContext(),
                        MainActivity2.class);
                i.putExtras(c);
                startActivity(i);
            }
        });
    }
}
