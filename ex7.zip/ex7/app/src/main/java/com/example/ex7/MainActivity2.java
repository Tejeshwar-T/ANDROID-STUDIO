package com.example.ex7;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        WebView web;
        Bundle bun = getIntent().getExtras();
        String lat = bun.getString("lat");
        String lon = bun.getString("lang");
        web = (WebView)findViewById(R.id.w1);
        WebSettings webSettings = web.getSettings();
        webSettings.setJavaScriptEnabled(true);

        web.loadUrl("https://www.google.co.in/maps/@"+lat+","+lon+",13z");
        web.setWebViewClient(new WebViewClient());
    }
}
